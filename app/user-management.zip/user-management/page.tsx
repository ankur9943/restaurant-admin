'use client'
import Image from 'next/image';
import React, { useState } from 'react'
import CampaignImage from '@/public/assets/images/campaign-image.png'
import Merchants from './merchants/page';
import StaffList from './staff/page';
import Link from 'next/link';
import { CrossIcon, FilterIcon } from '../helper/Svg';

export default function UserManagement() {
  const [activeTab, setActiveTab] = useState<string>("Merchants");

  return (
    <div>
      {/* Tabs Section */}
      <div className="grid grid-cols-3 border-b-8 border-[#F1F1F1] mb-4 [&>:last-child]:before:hidden">
        {["Merchants", "Staff", "Consumers"].map((tab) => (
          <button
            key={tab}
            className={`tab-style px-4 py-2 text-lg font-medium
            ${activeTab === tab ? "text-black/80 after:opacity-1" : "text-black/40 after:opacity-0"}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab} (1000)
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex justify-between space-x-2 items-center my-8">
        <div className="flex gap-2">
          <div>
            <label htmlFor="search-email" className="sr-only">Search By Name or Email</label>
            <div className="relative">
              <input type="search" name="search-email" placeholder="Search by Name or Email"
                className="text-sm font-medium border border-gray-2 py-2 px-3 pe-9 rounded-lg w-full placeholder:text-[#7A85B2] focus:border-dark-blue outline-none" />
              <button className="bg-black/25 rounded-full hover:bg-dark-blue transition-all absolute right-4 inline-block top-0 bottom-0 h-fit my-auto">
                <CrossIcon />
              </button>
            </div>
          </div>
          <div>
            <label htmlFor="search-district" className="sr-only">Search By City or District</label>
            <div className="relative">
              <input type="search" name="search-district" placeholder="Search By City or District"
                className="text-sm font-medium border border-gray-2 py-2 px-3 pe-9 rounded-lg w-full placeholder:text-[#7A85B2] focus:border-dark-blue outline-none" />
              <button className="bg-black/25 rounded-full hover:bg-dark-blue transition-all absolute right-4 inline-block top-0 bottom-0 h-fit my-auto">
                <CrossIcon />
              </button>
            </div>
          </div>
          <button type="button" className="px-4 py-2 rounded-lg bg-dark-blue text-white text-sm font-medium hover:opacity-85 transition-all duration-300">
            <FilterIcon />
          </button>
          <button type="button" className="border border-dark-blue px-4 py-2 rounded-lg text-dark-blue hover:bg-dark-blue hover:text-white text-sm font-medium hover:opacity-85 transition-all duration-300">
            Clear All <span>Filters(22)</span>
          </button>
        </div>

        <div className="flex space-x-2">
          <div className="inline-flex rounded-md shadow-xs" role="group">
            <button type="button" className="text-[#7A85B2] text-sm font-medium border-gray-2 px-3 py-2 border rounded-s-lg hover:bg-dark-blue hover:text-white transition-all duration-300">
              Approved
            </button>
            <button type="button" className="text-[#7A85B2] text-sm font-medium border-gray-2 px-3 py-2 border-t border-b hover:bg-dark-blue hover:text-white transition-all duration-300">
              Rejected
            </button>
            <button type="button" className="text-[#7A85B2] text-sm font-medium border-gray-2 px-3 py-2 rounded-e-lg hover:bg-dark-blue hover:text-white border transition-all duration-300">
              Pending
            </button>
          </div>
        </div>
      </div>


      {/* Conditional Rendering */}
      {activeTab === "Merchants" ? (
        <Merchants />
      ) : activeTab === "Staff" ? (
          <StaffList />
      ) : (
        <div>No content available for this tab.</div>
      )}








      {/* <div className='flex'>
        <div className='space-y-4'>
          <div className=''>
            <Image src={CampaignImage} alt="" />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px] rounded-md border border-gray-2 mt-1.5' required />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px]  rounded-md border border-gray-2 mt-1.5' required />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px]  rounded-md border border-gray-2 mt-1.5' required />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px]  rounded-md border border-gray-2 mt-1.5' required />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px]  rounded-md border border-gray-2 mt-1.5' required />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px] rounded-md border border-gray-2 mt-1.5' required />
          </div>
          <div className=''>
            <label htmlFor=''>Ad Campaign Place Format</label>
            <input type='text' name='campaign-format' className='w-full block min-h-[40px] rounded-md;border border-gray-2 mt-1.5' required />
          </div>

        </div>
        <hr className='h-full block w-2 bg-gray-2' />
        <div className=''></div>
      </div> */}

    </div>
  );
}
