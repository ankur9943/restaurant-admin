"use client";

import React, { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { EditIcons, LocationIcon, MoneyIcon, PhoneIcon } from "@/app/helper/Svg";

import StaffList from "../../staff/page";
import EmployeeCode from "@/app/components/model/EmployeeCode";

const merchantsData = [
    {
        "id": "1",
        "name": "John Doe",
        "email": "johndoe@gmail.com",
        "phone": "999999999",
        "city": "San Francisco",
        "status": "Banned"
    },
    {
        "id": "2",
        "name": "Jane Smith",
        "email": "janesmith@gmail.com",
        "phone": "888888888",
        "city": "Los Angeles",
        "status": "Active"
    },
    {
        "id": "3",
        "name": "Jane Smith",
        "email": "janesmith@gmail.com",
        "phone": "888888888",
        "city": "Los Angeles",
        "status": "Inactive"
    }
]

const MerchantProfile: React.FC = () => {
    const params = useParams();
    const [merchant, setMerchant] = useState<Merchant | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isPopupVisible, setPopupVisible] = useState<boolean>(false);

    useEffect(() => {
        const id = params?.id;

        if (typeof id === "string") {
            const merchantData = merchantsData.find((m) => m.id === id);
            if (merchantData) {
                setMerchant(merchantData);
            } else {
                setError("Merchant not found.");
            }
        } else {
            setError("Invalid merchant ID.");
        }
    }, [params]);

    if (error) {
        return <div className="text-center text-red-600 mt-10">{error}</div>;
    }

    if (!merchant) {
        return <div className="text-center mt-10">Loading merchant data...</div>;
    }

    return (

        <>

            {isPopupVisible && <EmployeeCode
                onClose={() => setPopupVisible(false)} />}

            <div className="border border-[#D9D9D9] rounded-lg p-8 flex">
                <div className="mb-4 w-[200px] flex-shrink">
                    <Image
                        src={merchant?.image ?? "/path/to/member.jpg"}
                        alt="Merchant Profile"
                        width={113}
                        height={113}
                        className="rounded-full bg-black/20 object-cover"
                    />
                </div>

                <div className='flex-grow'>
                    <div className="py-6 border-b border-[#D9D9D9] flex justify-between items-center">
                        <div className='space-y-2'>
                            <h4 className="text-lg font-medium text-[#353B40]">{merchant?.name ?? "Member Name"}</h4>
                            <p className='text-sm text-[#353B40]'>ID: {merchant?.id ?? "XXXXX"}</p>
                        </div>
                        <Link href={`#`}
                            onClick={() => setPopupVisible(true)}
                            title="Edit"
                            className="border border-black/10 rounded-lg p-2 hover:bg-dark-blue/10">
                            <EditIcons />
                        </Link>
                    </div>

                    <div className="mt-4">
                        <ul className="grid lg:grid-cols-2 space-y-2.5">
                            <li className="flex items-center space-x-2">
                                <LocationIcon />
                                <span className="text-sm xl:text-base space-x-2">
                                    <span className='text-[#5D6870]'>Location: </span>
                                    <span className='text-[#434A50]'>{merchant?.city ?? "Not available"}</span>
                                </span>
                            </li>
                            <li className="flex items-center space-x-2">
                                <PhoneIcon />
                                <span className="text-sm xl:text-base space-x-2">
                                    <span className='text-[#5D6870]'>Contact: </span>
                                    <span className='text-[#434A50]'>{merchant?.phone ?? "Not available"}</span>
                                </span>
                            </li>
                            <li className="flex items-center space-x-2">
                                <MoneyIcon />
                                <span className="text-sm xl:text-base space-x-2">
                                    <span className='text-[#5D6870]'>Active Subscription: </span>
                                    <span className='text-[#434A50]'>{merchant?.subscription ?? "Not available"}</span>
                                </span>
                            </li>
                            <li className="flex items-center space-x-2">
                                <MoneyIcon />
                                <span className="text-sm xl:text-base space-x-2">
                                    <span className='text-[#5D6870]'>Payout Status: </span>
                                    <span className='text-[#434A50]'>{merchant?.payoutStatus ?? "Not available"}</span>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div className="mt-16">
                <h1 className="text-2xl font-medium mb-4">Staff Details</h1>
                <StaffList />
            </div>
        </>

    );
};

export default MerchantProfile;
