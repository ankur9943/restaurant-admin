"use client";
import React from "react";
import Link from "next/link";
import { RightArrowIcon } from "@/app/helper/Svg";

const merchantsData = [
  {
    "id": "1",
    "name": "John Doe",
    "email": "johndoe@gmail.com",
    "phone": "999999999",
    "city": "San Francisco",
    "status": "Banned"
  },
  {
    "id": "2",
    "name": "Jane Smith",
    "email": "janesmith@gmail.com",
    "phone": "888888888",
    "city": "Los Angeles",
    "status": "Active"
  },
   {
    "id": "3",
    "name": "Jane Smith",
    "email": "janesmith@gmail.com",
    "phone": "888888888",
    "city": "Los Angeles",
    "status": "Inactive"
  }
]

const MerchantsList: React.FC = () => {
  return (
    <>
      <table className="w-full border-collapse text-sm border border-[#D9d9d9] text-center">
        <thead className='[&_th]:py-4 [&_th]:px-2  [&_th]:text-[#1A1D20] [&_th]:font-medium bg-[#E6E9EC] [&_th]:text-xs xl:[&_th]:text-sm mid-xl:[&_th]:text-base'>
          <tr>
            <th className='!px-4'>ID</th>
            <th>Merchants Name</th>
            <th>Email</th>
            <th>Contact Number</th>
            <th>City</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {merchantsData.map((merchant) => {
            return (
              <tr key={merchant.id}
                className="border-b border-[#E6E9EC] hover:bg-gray-50 [&_td]:text-[#2E3D52] [&_td]:font-medium [&_td]:p-2 [&_td]:text-xs xl:[&_td]:text-sm mid-xl:[&_td]:text-base">
                <td>{merchant.id}</td>
                <td>{merchant.name}</td>
                <td>{merchant.email}</td>
                <td>{merchant.phone}</td>
                <td>{merchant.city}</td>
                <td>
                  <div className="flex items-center justify-center space-x-2">
                    {/* Optional: small status dot */}
                    <span
                      className={`inline-block w-2 h-2 rounded-full
                        ${merchant.status === "Approved" || merchant.status === "Active"
                          ? "bg-green-500"
                          : merchant.status === "Inactive" || merchant.status === "Rejected"
                            ? "bg-[#D9D9D9]"
                            : merchant.status === "Banned" ? "bg-red-500"
                              : "bg-gray-500"
                        }`}
                    />
                    <span>
                      {merchant.status}
                    </span>
                  </div>
                </td>

                <td>
                  <Link
                    title="View Profile"
                    href={`/user-management/merchants/${merchant.id}`}
                    className="border border-black/10 rounded-lg p-2 hover:bg-dark-blue/10 inline-block">
                    <RightArrowIcon />
                  </Link>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </>
  );
};

export default MerchantsList;