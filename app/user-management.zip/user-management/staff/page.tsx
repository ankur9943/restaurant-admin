"use client";
import React from "react";
import Link from "next/link";
import { RightArrowIcon } from "@/app/helper/Svg";

const staffData = [
  {
    "id" : 121,
    "userName": "Alice Johnson",
    "staffName": "ShopSmart",
    "emailID": "alice.johnson@shopsmart.com",
    "contactNumber": "9876543210",
    "role": "Admin",
    "status": "Active",
  },
  {
    "id" : 122,
    "userName": "Bob Smith",
    "staffName": "TechTraders",
    "emailID": "bob.smith@techtraders.com",
    "contactNumber": "8765432109",
    "role": "Manager",
    "status": "Inactive",
  },
  {
    "id" : 123,
    "userName": "Charlie Brown",
    "staffName": "FreshMart",
    "emailID": "charlie.brown@freshmart.com",
    "contactNumber": "7654321098",
    "role": "Worker",
    "status": "Active",
  },
  {
    "id" : 124,
    "userName": "Diana Prince",
    "staffName": "StyleStudio",
    "emailID": "diana.prince@stylestudio.com",
    "contactNumber": "6543210987",
    "role": "Worker",
    "status": "Active",
  },
  {
    "id" : 125,
    "userName": "Edward Blake",
    "staffName": "HomeGoods",
    "emailID": "edward.blake@homegoods.com",
    "contactNumber": "5432109876",
    "role": "Worker",
    "status": "Inactive",
  },
  {
    "id" : 126,
    "userName": "Fiona Davis",
    "staffName": "PetStorePlus",
    "emailID": "fiona.davis@petstoreplus.com",
    "contactNumber": "4321098765",
    "role": "Manager",
    "status": "Active",
  },
  {
    "id" : 127,
    "userName": "George Taylor",
    "staffName": "Foodies",
    "emailID": "george.taylor@foodies.com",
    "contactNumber": "3210987654",
    "role": "Admin",
    "status": "Active",
  },
  {
    "id" : 128,
    "userName": "Hannah White",
    "staffName": "FashionHub",
    "emailID": "hannah.white@fashionhub.com",
    "contactNumber": "2109876543",
    "role": "Worker",
    "status": "Active",
  },
  {
    "id" : 129,
    "userName": "Ian Wright",
    "staffName": "QuickMarket",
    "emailID": "ian.wright@quickmarket.com",
    "contactNumber": "1098765432",
    "role": "Worker",
    "status": "Inactive",
  },
  {
    "id" : 130,
    "userName": "Jane Doe",
    "staffName": "DailyEssentials",
    "emailID": "jane.doe@dailyessentials.com",
    "contactNumber": "9988776655",
    "role": "Worker",
    "status": "Active",
  }
]

const StaffList: React.FC = () => {

  return (
    <>
      <table className="w-full border-collapse text-sm border border-[#D9d9d9] text-center">
        <thead className='[&_th]:py-4 [&_th]:px-2  [&_th]:text-[#1A1D20] [&_th]:font-medium bg-[#E6E9EC] [&_th]:text-xs xl:[&_th]:text-sm mid-xl:[&_th]:text-base'>
          <tr>
            <th className='!px-4'>ID</th>
            <th>User Name</th>
            <th>Staff Name</th>
            <th>Email ID</th>
            <th>Contact Number</th>
            <th>Role</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {staffData.map((staff) => {
            return (
              <tr key={staff.id}
                className="border-b border-[#E6E9EC] hover:bg-gray-50 [&_td]:text-[#2E3D52] [&_td]:font-medium [&_td]:p-2 [&_td]:text-xs xl:[&_td]:text-sm mid-xl:[&_td]:text-base">
                <td>{staff.id}</td>
                <td>{staff.userName}</td>
                <td>{staff.staffName}</td>
                <td>{staff.emailID}</td>
                <td>{staff.contactNumber}</td>
                <td>{staff.role}</td>
                <td>
                  <div className="flex items-center justify-center space-x-2">
                    {/* Optional: small status dot */}
                    <span
                      className={`inline-block w-2 h-2 rounded-full
                        ${staff.status === "Approved" || staff.status === "Active"
                          ? "bg-green-500"
                          : staff.status === "Inactive" || staff.status === "Rejected"
                            ? "bg-[#D9D9D9]"
                            : staff.status === "Banned" ? "bg-red-500"
                              : "bg-gray-500"
                        }`}
                    />
                    <span>
                      {staff.status}
                    </span>
                  </div>
                </td>
                <td>
                  <Link
                    title="View Profile"
                    href={`/user-management/staff/${staff.id}`}
                    className="border border-black/10 rounded-lg p-2 hover:bg-dark-blue/10 inline-block">
                    <RightArrowIcon />
                  </Link>
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </>
  );
};

export default StaffList;