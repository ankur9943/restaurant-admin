"use client";

import React, { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { EditIcons, LocationIcon, MoneyIcon, PhoneIcon } from "@/app/helper/Svg";

// Define Staff type
interface Staff {
    id: number;
    userName: string;
    staffName: string;
    emailID: string;
    contactNumber: string;
    role: string;
    status: string;
    image?: string;
    city?: string;
    phone?: string;
    subscription?: string;
    payoutStatus?: string;
}

const staffData = [
    {
        "id": 121,
        "userName": "Alice Johnson",
        "staffName": "ShopSmart",
        "emailID": "alice.johnson@shopsmart.com",
        "contactNumber": "9876543210",
        "role": "Admin",
        "status": "Active",
    },
    {
        "id": 122,
        "userName": "Bob Smith",
        "staffName": "TechTraders",
        "emailID": "bob.smith@techtraders.com",
        "contactNumber": "8765432109",
        "role": "Manager",
        "status": "Inactive",
    },
    {
        "id": 123,
        "userName": "Charlie Brown",
        "staffName": "FreshMart",
        "emailID": "charlie.brown@freshmart.com",
        "contactNumber": "7654321098",
        "role": "Worker",
        "status": "Active",
    },
    {
        "id": 124,
        "userName": "Diana Prince",
        "staffName": "StyleStudio",
        "emailID": "diana.prince@stylestudio.com",
        "contactNumber": "6543210987",
        "role": "Worker",
        "status": "Active",
    },
    {
        "id": 125,
        "userName": "Edward Blake",
        "staffName": "HomeGoods",
        "emailID": "edward.blake@homegoods.com",
        "contactNumber": "5432109876",
        "role": "Worker",
        "status": "Inactive",
    },
    {
        "id": 126,
        "userName": "Fiona Davis",
        "staffName": "PetStorePlus",
        "emailID": "fiona.davis@petstoreplus.com",
        "contactNumber": "4321098765",
        "role": "Manager",
        "status": "Active",
    },
    {
        "id": 127,
        "userName": "George Taylor",
        "staffName": "Foodies",
        "emailID": "george.taylor@foodies.com",
        "contactNumber": "3210987654",
        "role": "Admin",
        "status": "Active",
    },
    {
        "id": 128,
        "userName": "Hannah White",
        "staffName": "FashionHub",
        "emailID": "hannah.white@fashionhub.com",
        "contactNumber": "2109876543",
        "role": "Worker",
        "status": "Active",
    },
    {
        "id": 129,
        "userName": "Ian Wright",
        "staffName": "QuickMarket",
        "emailID": "ian.wright@quickmarket.com",
        "contactNumber": "1098765432",
        "role": "Worker",
        "status": "Inactive",
    },
    {
        "id": 130,
        "userName": "Jane Doe",
        "staffName": "DailyEssentials",
        "emailID": "jane.doe@dailyessentials.com",
        "contactNumber": "9988776655",
        "role": "Worker",
        "status": "Active",
    }
]

const StaffProfile: React.FC = () => {
    const params = useParams();
    const [staff, setStaff] = useState<Staff | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const idParam = params?.id;

        // Convert string param to number and compare
        if (typeof idParam === "string") {
            const staffId = parseInt(idParam, 10);
            const foundStaff = staffData.find((s) => s.id === staffId);

            if (foundStaff) {
                setStaff(foundStaff);
            } else {
                setError("Staff not found.");
            }
        } else {
            setError("Invalid Staff ID.");
        }
    }, [params]);

    if (error) {
        return <div className="text-center text-red-600 mt-10">{error}</div>;
    }

    if (!staff) {
        return <div className="text-center mt-10">Loading staff data...</div>;
    }

    return (
        <div className="border border-[#D9D9D9] rounded-lg p-8 flex">
            <div className="mb-4 w-[200px] flex-shrink">
                <Image
                    src={staff.image ?? "/images/default-avatar.png"}
                    alt="Staff Profile"
                    width={113}
                    height={113}
                    className="rounded-full bg-black/20 object-cover"
                />
            </div>

            <div className="flex-grow">
                <div className="py-6 border-b border-[#D9D9D9] flex justify-between items-center">
                    <div className="space-y-2">
                        <h4 className="text-lg font-medium text-[#353B40]">{staff.userName}</h4>
                        <p className="text-sm text-[#353B40]">ID: {staff.id}</p>
                    </div>
                    <Link
                        href="#"
                        title="Edit"
                        className="border border-black/10 rounded-lg p-2 hover:bg-dark-blue/10"
                    >
                        <EditIcons />
                    </Link>
                </div>

                <div className="mt-4">
                    <ul className="grid lg:grid-cols-2 space-y-2.5">
                        <li className="flex items-center space-x-2">
                            <LocationIcon />
                            <span className="text-sm xl:text-base">
                                <span className="text-[#5D6870]">Location: </span>
                                <span className="text-[#434A50]">{staff.city ?? "Not available"}</span>
                            </span>
                        </li>
                        <li className="flex items-center space-x-2">
                            <PhoneIcon />
                            <span className="text-sm xl:text-base">
                                <span className="text-[#5D6870]">Contact: </span>
                                <span className="text-[#434A50]">{staff.phone ?? "Not available"}</span>
                            </span>
                        </li>
                        <li className="flex items-center space-x-2">
                            <MoneyIcon />
                            <span className="text-sm xl:text-base">
                                <span className="text-[#5D6870]">Active Subscription: </span>
                                <span className="text-[#434A50]">{staff.subscription ?? "Not available"}</span>
                            </span>
                        </li>
                        <li className="flex items-center space-x-2">
                            <MoneyIcon />
                            <span className="text-sm xl:text-base">
                                <span className="text-[#5D6870]">Payout Status: </span>
                                <span className="text-[#434A50]">{staff.payoutStatus ?? "Not available"}</span>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    );
};

export default StaffProfile;
